/**
 * @fileoverview Modération des images avant publication ou envoi en message :
 * détection de nudité NudeNet (reprise de SAE_5.04, voir vendor/nudity-guard.js)
 * et détection de doigt d'honneur via MediaPipe Hands (voir
 * vendor/gesture-guard.js), puis pixellisation des zones détectées.
 * Tout s'exécute dans le navigateur.
 */

const TFJS_URL =
  'https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@4.10.0/dist/tf.min.js';
const NUDITY_GUARD_URL = 'js/vendor/nudity-guard.js';
const GESTURE_GUARD_URL = 'js/vendor/gesture-guard.js';
// Version épinglée, comme TFJS et NudeNet : sans numéro, jsDelivr sert la
// dernière version publiée, qui peut changer sans prévenir et casser l'analyse.
// MediaPipe charge ses propres assets (wasm, modèle) depuis ce même dossier.
const MEDIAPIPE_HANDS_BASE =
  'https://cdn.jsdelivr.net/npm/@mediapipe/hands@0.4.1675469240/';
const MEDIAPIPE_HANDS_URL = MEDIAPIPE_HANDS_BASE + 'hands.js';
// Marge ajoutée autour d'une main censurée, en pixels (repris de SAE_5.04).
const GESTURE_BOX_MARGIN = 30;
// Le détecteur agrandit déjà l'image à 800 px de petit côté ; une photo de
// smartphone en pleine résolution saturerait la mémoire GPU pour rien.
const MAX_IMAGE_SIDE = 1600;

let readyPromise = null;
// Deux inférences simultanées se disputent le GPU : on les enchaîne.
let analysisQueue = Promise.resolve();
// Instance MediaPipe Hands, réutilisée d'une image à l'autre (son chargement
// coûte plusieurs Mo, on ne la recrée pas à chaque upload).
let handsSolution = null;

/**
 * Charge un script classique (non module).
 * @param {string} src URL du script.
 * @return {Promise<void>}
 */
function loadScript(src) {
  return new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.src = src;
    script.onload = () => resolve();
    script.onerror = () => reject(new Error(`Chargement impossible : ${src}`));
    document.head.appendChild(script);
  });
}

/**
 * Instancie MediaPipe Hands une seule fois.
 * @return {Promise<void>}
 */
async function initHandsSolution() {
  if (handsSolution) return;
  const hands = new window.Hands({
    locateFile: (file) => MEDIAPIPE_HANDS_BASE + file,
  });
  hands.setOptions({
    maxNumHands: 2,
    modelComplexity: 1,
    minDetectionConfidence: 0.5,
    minTrackingConfidence: 0.5,
  });
  await hands.initialize();
  handsSolution = hands;
}

/**
 * Charge TensorFlow.js, le modèle NudeNet et MediaPipe Hands une seule fois.
 * @return {Promise<void>} Rejetée si l'un des deux détecteurs est indisponible.
 */
export function preloadModeration() {
  if (!readyPromise) {
    readyPromise = (async () => {
      if (!window.tf) await loadScript(TFJS_URL);
      // Recharger nudity-guard.js redéclarerait ses `const` globales (SyntaxError).
      if (!window.initNudeNetModel) await loadScript(NUDITY_GUARD_URL);
      if (!window.nudeNetReady) await window.initNudeNetModel();
      if (!window.nudeNetReady) throw new Error('Modèle NudeNet indisponible');

      if (!window.isMiddleFingerGesture) await loadScript(GESTURE_GUARD_URL);
      if (!window.Hands) await loadScript(MEDIAPIPE_HANDS_URL);
      await initHandsSolution();
      if (!handsSolution) throw new Error('MediaPipe Hands indisponible');
    })();
    readyPromise.catch(() => {
      readyPromise = null;
    });
  }
  return readyPromise;
}

/**
 * Analyse une image et pixellise les zones détectées (nudité + doigt d'honneur).
 * @param {File} file Image choisie par l'utilisateur.
 * @return {Promise<{file: File, detections: Array<Object>}>} Le fichier
 *     d'origine s'il n'y a rien à censurer, sinon une copie JPEG pixellisée.
 */
export function moderateImageFile(file) {
  const run = analysisQueue.then(() => analyzeAndCensor(file));
  analysisQueue = run.catch(() => {});
  return run;
}

/**
 * Repère les doigts d'honneur présents sur une image fixe.
 *
 * @param {HTMLCanvasElement} canvas Image à analyser.
 * @return {Promise<Array<Object>>} Boîtes à pixelliser, au même format que
 *     celles renvoyées par analyzeImageForNudity().
 */
async function detectMiddleFingerBoxes(canvas) {
  let results = null;
  handsSolution.onResults((r) => {
    results = r;
  });
  // L'API JS de MediaPipe est pensée pour un flux vidéo et conserve son suivi
  // d'une image à l'autre : sans ce reset, une main vue sur l'image précédente
  // pourrait être « retrouvée » sur la suivante.
  handsSolution.reset();
  await handsSolution.send({image: canvas});

  const mains = (results && results.multiHandLandmarks) || [];
  return mains
    .filter((landmarks) => window.isMiddleFingerGesture(landmarks))
    .map((landmarks) => ({
      // Pas de mirrorLandmarks() ici, contrairement à SAE_5.04 : une image
      // uploadée n'est pas en miroir, alors que l'aperçu webcam l'était.
      ...window.boundingBoxOf(
        landmarks,
        canvas.width,
        canvas.height,
        GESTURE_BOX_MARGIN,
        GESTURE_BOX_MARGIN,
      ),
      label: "doigt d'honneur",
      score: 1,
    }));
}

/**
 * @param {File} file Image à analyser.
 * @return {Promise<{file: File, detections: Array<Object>}>}
 */
async function analyzeAndCensor(file) {
  try {
    await preloadModeration();
  } catch (error) {
    console.error('Modération indisponible :', error);
    throw new Error(
      "L'analyse de l'image est indisponible : envoi bloqué. Réessayez.",
    );
  }

  let bitmap;
  try {
    bitmap = await createImageBitmap(file);
  } catch (error) {
    throw new Error("Impossible de lire cette image (format non pris en charge).");
  }

  const scale = Math.min(
    1,
    MAX_IMAGE_SIDE / Math.max(bitmap.width, bitmap.height),
  );
  const canvas = document.createElement('canvas');
  canvas.width = Math.round(bitmap.width * scale);
  canvas.height = Math.round(bitmap.height * scale);
  const ctx = canvas.getContext('2d', {willReadFrequently: true});
  ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  bitmap.close();

  // Les deux modèles tournent l'un après l'autre : lancés en parallèle, ils se
  // disputeraient le GPU (constat déjà fait sur SAE_5.04).
  const zonesNudite = await window.analyzeImageForNudity(canvas);
  const zonesGeste = await detectMiddleFingerBoxes(canvas);
  const detections = [...zonesNudite, ...zonesGeste];

  console.log('Modération image —', {
    fichier: file.name,
    taille: `${canvas.width}x${canvas.height}`,
    nudite: zonesNudite.length,
    doigtDHonneur: zonesGeste.length,
    zones: detections.map((d) => ({label: d.label, score: d.score.toFixed(2)})),
  });

  if (detections.length === 0) {
    return {file, detections};
  }

  detections.forEach((box) => window.pixelateBox(ctx, box));
  const blob = await new Promise((resolve) =>
    canvas.toBlob(resolve, 'image/jpeg', 0.92),
  );
  const name = file.name.replace(/\.[^.]*$/, '') + '.jpg';
  return {file: new File([blob], name, {type: 'image/jpeg'}), detections};
}
